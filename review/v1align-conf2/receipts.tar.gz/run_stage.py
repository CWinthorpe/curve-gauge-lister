#!/usr/bin/env python3
"""Independent bounded review runner. Never edits any Solidity input.

Apply/revert the separately saved diffs only in the disposable copies.
Every invocation hashes relative input paths in the actual execution copy,
records native stdout/stderr and exit, and checks exact selected results.
"""
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent
RECEIPTS = ROOT / "receipts"
PINS = json.loads((RECEIPTS / "baseline-hashes.json").read_text())
TESTS = {
    "vc01": "test_KillAtEachReleaseCount",
    "vc02": "test_AuditM01_AccountingHorizonIncludesPartialWeekEdges",
}
LABELS = {
    "vc01": "FD got exactly the unreleased",
    "vc02": "next call did not revert as expected",
}


def snapshot(copy):
    actual = {
        p: hashlib.sha256((copy / p).read_bytes()).hexdigest()
        for p in PINS
    }
    discovered = {
        str(p.relative_to(copy))
        for d in ("contracts", "test", "fork", "scripts")
        for p in (copy / d).rglob("*") if p.is_file()
    } | {"foundry.toml"}
    assert discovered == set(PINS), ("input inventory changed", discovered ^ set(PINS))
    return actual


def main():
    case, stage = sys.argv[1:]
    copy = ROOT / case
    name = TESTS[case]
    selected = [
        "forge", "test", "--offline", "--match-path", "test/Settlement.t.sol",
        "--match-contract", "^SettlementTest$", "--match-test",
        "^" + re.escape(name + "()") + "$", "-vvvv",
    ]
    if stage == "list":
        argv = ["forge", "test", "--offline", "--list", "--json"]
    elif stage.startswith("probe-"):
        argv = selected.copy()
        argv[-2] = "^" + re.escape(name + "[" + stage[6:] + "]()") + "$"
    elif stage == "offline":
        argv = ["forge", "test", "--offline", "-vvv"]
    elif stage == "config":
        argv = ["forge", "config", "--json"]
    elif stage == "version":
        argv = ["forge", "--version"]
    elif stage == "fmt":
        argv = ["forge", "fmt", "--check"]
    else:
        assert stage in ("pristine", "red", "restored")
        argv = selected

    env = {
        k: v for k, v in os.environ.items()
        if not k.startswith(("FOUNDRY_", "DAPP_")) and k != "MAINNET_RPC_URL"
    }
    env.update(FOUNDRY_PROFILE="default", NO_COLOR="1", TERM="dumb")
    before = snapshot(copy)
    changed = sorted(p for p in PINS if before[p] != PINS[p])
    mutated = stage == "red" or stage.startswith("probe-")
    assert changed == (["contracts/CurveGaugeLister.sol"] if mutated else []), changed
    if stage == "red":
        import difflib
        rel = "contracts/CurveGaugeLister.sol"
        diff = "".join(difflib.unified_diff(
            (ROOT / "candidate" / rel).read_text().splitlines(keepends=True),
            (copy / rel).read_text().splitlines(keepends=True),
            fromfile="a/" + rel, tofile="b/" + rel,
        ))
        (RECEIPTS / (case + ".patch")).write_text(diff)
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    clock = time.monotonic()
    result = subprocess.run(argv, cwd=copy, env=env, capture_output=True)
    elapsed = time.monotonic() - clock
    after = snapshot(copy)
    prefix = RECEIPTS / (case + "." + stage)
    prefix.with_suffix(prefix.suffix + ".stdout").write_bytes(result.stdout)
    prefix.with_suffix(prefix.suffix + ".stderr").write_bytes(result.stderr)
    out = result.stdout.decode(errors="replace")
    combined = out + result.stderr.decode(errors="replace")
    fail_lines = [line for line in out.splitlines() if line.startswith("[FAIL")]
    pass_lines = [line for line in out.splitlines() if line.startswith("[PASS]")]
    record = {
        "case": case, "stage": stage, "argv": argv, "cwd": str(copy),
        "started_utc": started, "elapsed_seconds": elapsed,
        "exit_code": result.returncode,
        "environment_policy": "All FOUNDRY_*/DAPP_* overrides and MAINNET_RPC_URL removed; FOUNDRY_PROFILE=default; NO_COLOR=1; TERM=dumb",
        "hashes_before": before, "hashes_after": after,
        "changed_inputs_vs_candidate": changed,
        "inputs_unchanged_during_execution": before == after,
        "test_fork_bytes_match_candidate": all(
            after[p] == PINS[p] for p in PINS if p.split("/")[0] in ("test", "fork")
        ),
        "stdout_sha256": hashlib.sha256(result.stdout).hexdigest(),
        "stderr_sha256": hashlib.sha256(result.stderr).hexdigest(),
        "pass_lines": pass_lines, "fail_lines": fail_lines,
        "summary_lines": [line for line in out.splitlines() if line.startswith(("Ran ", "Suite result:"))],
    }
    prefix.with_suffix(prefix.suffix + ".json").write_text(json.dumps(record, indent=2) + "\n")
    assert before == after
    assert record["test_fork_bytes_match_candidate"]
    if stage in ("pristine", "restored", "red"):
        assert out.count("Ran 1 test for test/Settlement.t.sol:SettlementTest") == 1, combined
        if stage == "red":
            assert result.returncode == 1, combined
            assert len(fail_lines) == 2 and not pass_lines, combined
            assert all("[FAIL: " + LABELS[case] + "] " + name + "()" in line for line in fail_lines), combined
            assert "0 passed; 1 failed; 0 skipped" in out, combined
            if case == "vc01":
                assert "ConfiscationDeltaMismatch" not in out
                assert "[Revert] FD got exactly the unreleased" in out
        else:
            assert result.returncode == 0 and len(pass_lines) == 1 and not fail_lines, combined
            assert "[PASS] " + name + "()" in out and "1 passed; 0 failed; 0 skipped" in out, combined
    elif stage.startswith("probe-"):
        assert result.returncode == 0 and not pass_lines and not fail_lines
        assert "No tests found" in combined or "No tests match" in combined, combined
    elif stage == "offline":
        assert result.returncode == 0 and len(pass_lines) == 77 and not fail_lines, combined
        assert "77 tests passed, 0 failed, 0 skipped" in out, combined
    else:
        assert result.returncode == 0, combined
    print(json.dumps({k: record[k] for k in (
        "case", "stage", "exit_code", "elapsed_seconds", "changed_inputs_vs_candidate",
        "inputs_unchanged_during_execution", "test_fork_bytes_match_candidate", "summary_lines", "fail_lines",
    )}, indent=2), flush=True)


if __name__ == "__main__":
    main()
