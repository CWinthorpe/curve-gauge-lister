#!/usr/bin/env python3
"""Reconstruct the approved amendment and seal new review evidence only."""
import difflib
import hashlib
import io
import json
from pathlib import Path
import subprocess
import tarfile

ROOT = Path(__file__).resolve().parent
REPO = Path("/home/winny/curve-gauge-lister")
R = ROOT / "receipts"
BINDING = json.loads((R / "binding.json").read_text())


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def main():
    subprocess.run(["python", str(ROOT / "verify_receipts.py")], check=True, stdout=subprocess.DEVNULL)
    path = "plans/V1ALIGN-WITNESSES.md"
    before = (R / "witness-authority.before.md").read_bytes()
    assert before == subprocess.check_output(["git", "show", BINDING["candidate"] + ":" + path], cwd=REPO)
    ruling = (R / "vc02-ruling.txt").read_text()
    old = ruling.split("Original witness row:\n", 1)[1].split("\n\n", 1)[0]
    new = ruling.split("Approved replacement row:\n", 1)[1].split("\n\n", 1)[0]
    appendix = ruling.split("Approved append-only section:\n", 1)[1]
    assert before.decode().count(old) == 1
    approved = (before.decode().replace(old, new) + "\n" + appendix).encode()
    after = (REPO / path).read_bytes()
    assert after == approved
    diff = "".join(difflib.unified_diff(before.decode().splitlines(keepends=True), after.decode().splitlines(keepends=True), fromfile="a/" + path, tofile="b/" + path)).encode()
    (R / "witness-authority.patch").write_bytes(diff)
    (R / "witness-authority.after.md").write_bytes(after)
    command = ["patch", "--batch", "--fuzz=0", "--silent", "--output=-", str(R / "witness-authority.before.md"), str(R / "witness-authority.patch")]
    reconstructed = subprocess.run(command, capture_output=True)
    assert reconstructed.returncode == 0 and reconstructed.stdout == after
    checks = []
    for argv in (
        ["git", "diff", "--exit-code", BINDING["product_base"], "--", "contracts", "test", "fork", "scripts", "foundry.toml"],
        ["git", "diff", "--exit-code", BINDING["candidate"], "--", "review/v1align-execution", "review/V1ALIGN-CONF.md"],
        ["git", "diff", "--check"],
    ):
        result = subprocess.run(argv, cwd=REPO, capture_output=True)
        assert result.returncode == 0 and not result.stdout and not result.stderr
        checks.append({"argv": argv, "exit_code": result.returncode, "stdout": "", "stderr": ""})
    result = {
        "status": "APPROVED_AND_APPLIED",
        "candidate": BINDING["candidate"], "authority_path": path,
        "before_sha256": sha(before), "after_sha256": sha(after), "diff_sha256": sha(diff),
        "exact_approved_row_and_appendix_only": True,
        "reconstruction_argv": command, "reconstruction_exit": reconstructed.returncode,
        "reconstruction_byte_equal": reconstructed.stdout == after,
        "git_preservation_checks": checks,
    }
    (R / "amendment-verification.json").write_text(json.dumps(result, indent=2) + "\n")
    inputs = subprocess.check_output(["git", "archive", BINDING["candidate"], *BINDING["archive_paths"]], cwd=REPO)
    assert sha(inputs) == BINDING["source_archive_sha256"]
    files = {"receipts/" + p.name: p.read_bytes() for p in sorted(R.iterdir()) if p.is_file()}
    files.update({p: (ROOT / p).read_bytes() for p in ("run_stage.py", "verify_receipts.py", "seal_receipts.py", "REPLAY.txt")})
    files["candidate-inputs.tar"] = inputs
    manifest = {name: {"sha256": sha(raw), "bytes": len(raw)} for name, raw in sorted(files.items())}
    files["receipt-manifest.json"] = (json.dumps(manifest, indent=2) + "\n").encode()
    dest = REPO / "review/v1align-conf2/receipts.tar.gz"
    dest.parent.mkdir(exist_ok=True)
    assert not dest.exists(), "Refuse to overwrite sealed evidence"
    with tarfile.open(dest, "w:gz") as tf:
        for name, raw in sorted(files.items()):
            info = tarfile.TarInfo(name)
            info.size = len(raw)
            info.mode = 0o644
            info.mtime = 0
            tf.addfile(info, io.BytesIO(raw))
    with tarfile.open(dest) as tf:
        members = [m for m in tf.getmembers() if m.isfile()]
        assert {m.name for m in members} == set(files)
        for m in members:
            assert tf.extractfile(m).read() == files[m.name]
    print(json.dumps({"archive": str(dest), "archive_sha256": sha(dest.read_bytes()), "archive_bytes": dest.stat().st_size, "verified_members": len(files), "amendment": result}, indent=2))


if __name__ == "__main__":
    main()
