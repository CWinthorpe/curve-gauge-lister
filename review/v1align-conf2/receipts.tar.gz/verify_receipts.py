#!/usr/bin/env python3
"""Verify the independently collected receipts and their candidate binding."""
import ast
import hashlib
import json
from pathlib import Path
import re
import subprocess
import tarfile

ROOT = Path(__file__).resolve().parent
REPO = Path("/home/winny/curve-gauge-lister")
R = ROOT / "receipts"
PINS = json.loads((R / "baseline-hashes.json").read_text())
BINDING = json.loads((R / "binding.json").read_text())
CL = "contracts/CurveGaugeLister.sol"
TEST = "test_AuditM01_AccountingHorizonIncludesPartialWeekEdges"


def sha(data):
    return hashlib.sha256(data).hexdigest()


def line_hits(text, needle):
    return [i for i, line in enumerate(text.splitlines(), 1) if needle in line]


def mutation_from_script(case):
    path = REPO / "review/v1align-execution/gates" / (case + "_falsifiers.py")
    tree = ast.parse(path.read_text())
    values = {}
    allowed = {"SINK", "SPLIT_EDITS", "CHECK2_EDIT"} if case == "vc01" else {"EDIT"}
    for node in tree.body:
        if isinstance(node, ast.Assign) and len(node.targets) == 1 and isinstance(node.targets[0], ast.Name):
            key = node.targets[0].id
            if key in allowed:
                values[key] = eval(compile(ast.Expression(node.value), str(path), "eval"), {"__builtins__": {}}, values)
    edits = values["SPLIT_EDITS"] + values["CHECK2_EDIT"] if case == "vc01" else values["EDIT"]
    source = (ROOT / "candidate" / CL).read_text()
    for old, new in edits:
        assert source.count(old) == 1
        source = source.replace(old, new)
    return source.encode()


def main():
    for p, expected in PINS.items():
        raw = subprocess.check_output(["git", "show", BINDING["candidate"] + ":" + p], cwd=REPO)
        assert sha(raw) == expected
        for copy in ("candidate", "vc01", "vc02"):
            assert sha((ROOT / copy / p).read_bytes()) == expected
        assert sha((REPO / p).read_bytes()) == expected
    executions = {}
    for record_path in sorted(R.glob("vc0*.*.json")):
        rec = json.loads(record_path.read_text())
        if "argv" not in rec:
            continue
        prefix = record_path.name[:-5]
        for stream in ("stdout", "stderr"):
            assert sha((R / (prefix + "." + stream)).read_bytes()) == rec[stream + "_sha256"]
        assert rec["hashes_before"] == rec["hashes_after"]
        expected_hashes = PINS.copy()
        if rec["stage"] == "red" or rec["stage"].startswith("probe-"):
            expected_hashes[CL] = sha(mutation_from_script(rec["case"]))
        assert rec["hashes_before"] == expected_hashes
        executions[prefix] = rec["exit_code"]
    for case in ("vc01", "vc02"):
        assert [executions[case + "." + s] for s in ("pristine", "red", "restored")] == [0, 1, 0]
        result = subprocess.run(["patch", "--batch", "--fuzz=0", "--silent", "--output=-", str(ROOT / "candidate" / CL), str(R / (case + ".patch"))], capture_output=True)
        assert result.returncode == 0 and result.stdout == mutation_from_script(case)

    artifact = json.loads((ROOT / "vc01/out/Settlement.t.sol/SettlementTest.json").read_text())
    methods = {name: artifact["methodIdentifiers"][name] for name in ("test_KillAtEachReleaseCount()", TEST + "()")}
    inventory = json.loads((R / "vc02.list.stdout").read_text())
    discovered = {f + ":" + c + ":" + n for f, contracts in inventory.items() for c, names in contracts.items() for n in names}
    authority = json.loads((REPO / "plans/V1ALIGN-WITNESS-INVENTORY.json").read_text())
    expected = {row["target_identity_or_counterpart"] for row in authority["identities"] if row["profile"] == "default" and row["disposition"] in ("RETAIN_V1", "PORT_TRUST")}
    actual = []
    for line in (R / "vc01.offline.stdout").read_text().splitlines():
        if line.startswith("Ran ") and " tests for " in line:
            suite = line.split(" tests for ", 1)[1]
        elif line.startswith("[PASS]"):
            signature = line.split()[1]
            assert signature.endswith("()")
            actual.append(suite + ":" + signature[:-2])
    assert set(actual) == discovered == expected and len(actual) == len(set(actual)) == 77
    loop_ids = sorted(x for x in discovered if x.endswith(":" + TEST))
    assert loop_ids == ["test/Settlement.t.sol:SettlementTest:" + TEST]

    # Source-bound independent cell arithmetic, not copied attribution constants.
    fixture = (ROOT / "candidate/test/Settlement.t.sol").read_text()
    t0_match = re.search(r"\bT0\s*=\s*([\d_]+)", fixture)
    assert t0_match
    t0 = int(t0_match[1].replace("_", ""))
    week = 604800
    cells = [(0, 10, 0), (1, 40, 1), (2, 70, week - 1)]
    frames = {}
    for stage in ("pristine", "red", "restored"):
        text = (R / ("vc02." + stage + ".stdout")).read_text()
        frames[stage] = {}
        for index, base_weeks, offset in cells:
            cursor = t0 + base_weeks * week + offset
            h = (cursor // week) * week + 20 * week
            frames[stage][str(index)] = {
                "offset": offset, "cursor": cursor, "H": h,
                "cursor_lines": line_hits(text, "setLastTokenTime(" + str(cursor)),
                "warp_lines": {str(w): line_hits(text, "VM::warp(" + str(w)) for w in (h - 1, h, h + 1)},
                "raw_span_at_H_plus_1": h + 1 - cursor,
                "floored_span_at_H_plus_1": h + 1 - (cursor // week) * week,
            }
            count = 0 if stage == "red" and index == 2 else 3
            assert len(frames[stage][str(index)]["cursor_lines"]) == count
            assert all(len(hits) == int(count > 0) for hits in frames[stage][str(index)]["warp_lines"].values())
    vc01red = (R / "vc01.red.stdout").read_text()
    vc02red = (R / "vc02.red.stdout").read_text()
    assert line_hits(vc01red, "[Revert] FD got exactly the unreleased") == [184]
    assert "ConfiscationDeltaMismatch" not in vc01red
    assert line_hits(vc02red, "[Revert] next call did not revert as expected") == [1079]
    for name in ("cell0_offset0", "cell1_offset1", "cell2_weekminus1"):
        prefix = "vc02.probe-" + name
        text = (R / (prefix + ".stdout")).read_text() + (R / (prefix + ".stderr")).read_text()
        assert executions[prefix] == 0 and "No tests found" in text
        assert not re.search(r"\[(?:PASS|FAIL)|Ran \d+ tests? for", text)

    stored = {}
    for case in ("vc01", "vc02"):
        archive = REPO / "review/v1align-execution/gates" / (case + "-falsify-logs.tar.gz")
        checks = []
        with tarfile.open(archive) as tf:
            for line in (ROOT / "stored" / case / "sha256.txt").read_text().splitlines():
                digest, relative = line.split(maxsplit=1)
                member = case + "/" + relative.removeprefix("./")
                data = tf.extractfile(member).read()
                assert sha(data) == digest
                assert data == (ROOT / "stored" / member).read_bytes()
                checks.append(member)
        stored[case] = {"archive_sha256": sha(archive.read_bytes()), "verified_manifest_members": checks}
    stored_red = (ROOT / "stored/vc02" / (TEST + ".red.log")).read_text()
    assert line_hits(stored_red, "[Revert] next call did not revert as expected") == [1081]
    assert not line_hits(stored_red, "setLastTokenTime(1837382399")

    config = json.loads((R / "vc01.config.stdout").read_text())
    settings = {k: config[k] for k in ("solc", "optimizer", "optimizer_runs", "via_ir", "evm_version", "test", "out")}
    assert settings == {"solc": "0.8.30", "optimizer": True, "optimizer_runs": 200, "via_ir": False, "evm_version": "paris", "test": "test", "out": "out"}
    summary = {
        "binding": BINDING, "native_exits": executions,
        "all_candidate_inputs_verified": len(PINS),
        "test_fork_files_verified_every_stage": sum(p.split("/")[0] in ("test", "fork") for p in PINS),
        "both_mutations_exactly_match_committed_generators": True,
        "both_patches_reconstructed_with_zero_fuzz": True,
        "both_copies_fully_restored": True,
        "compiler": json.loads(artifact["rawMetadata"])["compiler"], "config": settings,
        "selected_method_identifiers": methods, "compiled_horizon_ids": loop_ids,
        "offline_exact_inventory_count": len(actual), "offline_exact_inventory": sorted(actual),
        "vc02_cell_frames": frames, "stored_receipt_checks": stored,
        "decisive_trace_lines": {"receipts/vc01.red.stdout": 184, "receipts/vc02.red.stdout": 1079, "stored/vc02/" + TEST + ".red.log": 1081},
        "warnings": [line for line in (R / "vc01.offline.stdout").read_text().splitlines() if line.startswith("Warning (")],
    }
    (R / "verification.json").write_text(json.dumps(summary, indent=2) + "\n")
    print(json.dumps({k: v for k, v in summary.items() if k not in ("offline_exact_inventory", "vc02_cell_frames", "stored_receipt_checks")}, indent=2))
    print("VC02 cursor frame counts:", {s: {i: len(v["cursor_lines"]) for i, v in row.items()} for s, row in frames.items()})


if __name__ == "__main__":
    main()
