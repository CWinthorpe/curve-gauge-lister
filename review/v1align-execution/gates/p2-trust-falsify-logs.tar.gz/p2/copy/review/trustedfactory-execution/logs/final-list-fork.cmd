== list-fork :: FOUNDRY_PROFILE=fork forge test --offline --list --json
exit=0
