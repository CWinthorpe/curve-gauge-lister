== default-run1 :: -u MAINNET_RPC_URL FOUNDRY_PROFILE=default FOUNDRY_FUZZ_SEED=0x5eedb0 FOUNDRY_FUZZ_RUNS=256 forge test --offline -vvv
exit=0
