== default-run2 :: MAINNET_RPC_URL=http://127.0.0.1:1 FOUNDRY_PROFILE=default FOUNDRY_FUZZ_SEED=0x5eedb0 FOUNDRY_FUZZ_RUNS=256 forge test --offline -vvv
exit=0
