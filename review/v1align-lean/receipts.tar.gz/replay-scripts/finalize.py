#!/usr/bin/env python3
"""Independently reconcile native gates, cut commits and append-only evidence."""
from pathlib import Path
import hashlib
import json
import re
import shutil
import subprocess
import tarfile

root = Path('/home/winny/curve-gauge-lister')
work = Path(__file__).resolve().parent
receipts = work / 'receipts'
base = 'ce0fe3ae957057564f76623b181ec825fe72a942'
brief = '14c2d9e3b2ab1b35c1228d38ab1d60ebcce71573'
accepted_stages = ['baseline', 'L01-trial', 'L01-cleaned', 'L02-trial', 'L02-landed']
fixture = 'test/fork/ForkFixture.sol'


def git(*args):
    return subprocess.check_output(['git', *args], cwd=root)


def load(stage, name):
    return json.loads((receipts / stage / name).read_text())


def sha(data):
    return hashlib.sha256(data).hexdigest()


baseline = load('baseline', 'input-after.json')
ids = load('baseline', 'identities.json')
base_sizes = load('baseline', 'sizes.json')
checks = {}
for stage in accepted_stages:
    r = receipts / stage
    verification = load(stage, 'verification.json')
    assert load(stage, 'input-before.json') == load(stage, 'input-after.json')
    assert load(stage, 'identities.json') == ids
    checks[stage] = {'commands': {}, 'native_census': {}}
    for cmd in verification['commands']:
        name = cmd['name']
        native = load(stage, name + '.json')
        expected_exit = 1 if name == 'fork-unreachable' else 0
        assert native['exit'] == expected_exit
        checks[stage]['commands'][name] = native['exit']
    for profile, runs in [('default', ['offline-unset', 'offline-unreachable']), ('fork', ['fork-online', 'fork-warm'])]:
        expected = set(ids[profile]['expected'])
        assert len(expected) == (77 if profile == 'default' else 13)
        for name in runs:
            text = (r / (name + '.stdout')).read_text()
            actual = []
            for block in re.split(r'(?=^Ran \d+ tests? for )', text, flags=re.M):
                suite = re.match(r'Ran \d+ tests? for ([^\n]+)', block)
                if suite:
                    actual.extend(suite[1] + ':' + sig for sig in re.findall(r'^\[PASS\] (.*?) \(gas:', block, re.M))
            assert len(actual) == len(set(actual)) == len(expected)
            assert set(actual) == expected
            assert '[FAIL' not in text and '[SKIP' not in text
            summary = re.findall(r'(\d+) tests passed, (\d+) failed, (\d+) skipped', text)[-1]
            assert tuple(map(int, summary)) == (len(expected), 0, 0)
            checks[stage]['native_census'][name] = len(actual)
        assert load(stage, 'sizes.json')[profile]['CurveGaugeLister.sol/CurveGaugeLister.json'] == base_sizes[profile]['CurveGaugeLister.sol/CurveGaugeLister.json']
        for name in ['CurveGaugeLister', 'VotiumAdapter', 'VoteMarketAdapter']:
            assert (r / 'artifacts' / (profile + '-' + name + '.json')).read_bytes() == (receipts / 'baseline/artifacts' / (profile + '-' + name + '.json')).read_bytes()
    negative = ''.join((r / ('fork-unreachable.' + suffix)).read_text() for suffix in ('stdout', 'stderr'))
    assert 'refusing to run fork tests' in negative and '[PASS]' not in negative and 'Ran ' not in negative
    for name in ('fork-online', 'fork-warm'):
        preflight = (r / (name + '.stderr')).read_text()
        assert 'chainId=0x1 number=0x192d8fb hash=0x55810b079923a14fb97ad548f5024f65530dbc4fb2357a38f41e13b3d27cb6d3 timestamp=0x6af61657' in preflight
    current = load(stage, 'input-after.json')
    changed = sorted(p for p in baseline if baseline[p] != current.get(p))
    assert changed == ([] if stage == 'baseline' else [fixture])
    assert sorted(set(current) - set(baseline)) in ([], ['plans/V1ALIGN-LEAN-BRIEF.md'])
    checks[stage]['frozen_input_diff'] = []
for trial, landed in [('L01-trial', 'L01-cleaned'), ('L02-trial', 'L02-landed')]:
    assert load(trial, 'sizes.json') == load(landed, 'sizes.json')
    assert all(load(landed, 'input-after.json').get(p) == h for p, h in load(trial, 'input-after.json').items())
for item in ('L01', 'L02'):
    assert load(item + '-custody', 'restored.json')['all_predecessor_inputs_exact']
    assert load(item + '-custody', 'applied.json')['trial_patch_exact']
    assert load(item + '-custody', 'trial.json')['frozen_all_other_tracked_paths_byte_equal']

commits = git('rev-list', '--reverse', brief + '..HEAD').decode().splitlines()
assert len(commits) == 2, commits
commit_data = {}
for item, commit, stage in zip(('L01', 'L02'), commits, ('L01-cleaned', 'L02-landed')):
    assert git('show', '-s', '--format=%s', commit).decode().startswith('v1align-lean:')
    paths = git('diff-tree', '--no-commit-id', '--name-only', '-r', commit).decode().splitlines()
    assert paths == [fixture], paths
    diff = git('diff', commit + '^', commit, '--', fixture)
    assert diff == (receipts / (item + '-custody/cut.patch')).read_bytes()
    for file, h in load(stage, 'input-after.json').items():
        assert sha(git('show', commit + ':' + file)) == h, (commit, file)
    commit_data[item] = {'commit': commit, 'parent': git('rev-parse', commit + '^').decode().strip(), 'subject': git('show', '-s', '--format=%s', commit).decode().strip(), 'paths': paths, 'patch_sha256': sha(diff), 'gated_input_tree_exact': True}
assert not git('diff', '--name-only')
assert not git('diff', '--cached', '--name-only')
assert git('diff', '--name-only', base, 'HEAD', '--', 'contracts', 'foundry.toml', 'scripts', 'docs', 'README.md', 'review') == b''
final_data = {'reviewed_candidate': base, 'review_checkout_brief': brief, 'shipping_cut_head': commits[-1], 'commits': commit_data, 'accepted_stages': checks, 'frozen_paths_unchanged': True, 'product_compiler_artifacts_byte_identical_in_all_accepted_stages': True, 'initial_landed_stale_artifact_disposition': load('L01-artifact-cleanup', 'diagnosis.json')}
(receipts / 'FINAL-VERIFICATION.json').write_text(json.dumps(final_data, indent=2, sort_keys=True) + '\n')

scripts = receipts / 'replay-scripts'
scripts.mkdir(exist_ok=False)
for name in ('gates.py', 'sweep.py', 'custody.py', 'clean_artifacts.py', 'finalize.py'):
    shutil.copy2(work / name, scripts / name)
manifest = {str(p.relative_to(receipts)): {'bytes': p.stat().st_size, 'sha256': sha(p.read_bytes())} for p in sorted(receipts.rglob('*')) if p.is_file()}
(receipts / 'receipt-manifest.json').write_text(json.dumps(manifest, indent=2, sort_keys=True) + '\n')
output = root / 'review/v1align-lean/receipts.tar.gz'
output.parent.mkdir(exist_ok=True)
assert not output.exists()
with tarfile.open(output, 'w:gz') as tar:
    for file in sorted(receipts.rglob('*')):
        if file.is_file():
            tar.add(file, arcname=str(file.relative_to(receipts)))
with tarfile.open(output, 'r:gz') as tar:
    members = [m for m in tar.getmembers() if m.isfile()]
    assert len(members) == len(manifest) + 1
    for member in members:
        data = tar.extractfile(member).read()
        assert data == (receipts / member.name).read_bytes()
        if member.name != 'receipt-manifest.json':
            assert sha(data) == manifest[member.name]['sha256'] and len(data) == manifest[member.name]['bytes']
print(json.dumps({'bundle': str(output), 'sha256': sha(output.read_bytes()), 'bytes': output.stat().st_size, 'verified_file_members': len(members), 'commits': commit_data, 'native_gate_rounds_accepted': len(accepted_stages)}, indent=2))
