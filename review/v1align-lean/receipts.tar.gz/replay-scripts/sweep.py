#!/usr/bin/env python3
"""Bind lean search evidence to ce0fe3a; rebuild pre-amendment product sizes."""
from collections import Counter, defaultdict
from pathlib import Path
import datetime
import hashlib
import json
import os
import re
import subprocess
import time

ROOT = Path('/home/winny/curve-gauge-lister')
WORK = Path(__file__).resolve().parent
OUT = WORK / 'receipts/sweep'
OUT.mkdir(parents=True, exist_ok=False)
BASE = 'e18bee54c08832dd7fd6d0a11932290155bf9178'
CAND = 'ce0fe3ae957057564f76623b181ec825fe72a942'
SCOPES = ['contracts', 'test', 'fork', 'scripts']


def save(name, data):
    (OUT / name).write_text(json.dumps(data, indent=2, sort_keys=True) + '\n')


def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT)


def tree(revision, paths):
    names = git('ls-tree', '-r', '--name-only', revision, '--', *paths).decode().splitlines()
    return {p: git('show', revision + ':' + p).decode() for p in names}


old, new = tree(BASE, SCOPES), tree(CAND, SCOPES)
code = {p: re.sub(r'/\*.*?\*/|//[^\n]*', '', s, flags=re.S) for p, s in new.items()}
counts = Counter(re.findall(r'\b[A-Za-z_]\w*\b', '\n'.join(code.values())))
defs = defaultdict(list)
for file, text in code.items():
    for m in re.finditer(r'\b(function|event|error|contract|interface|library|constant)\s+(\w+)', text):
        defs[m[2]].append({'file': file, 'kind': m[1]})
low = {name: sites for name, sites in defs.items() if counts[name] <= len(sites) and not name.startswith('test') and not all(s['kind'] == 'contract' for s in sites)}
no_local_import_use = []
for file, text in code.items():
    for m in re.finditer(r'import\s*\{(.*?)\}\s*from\s*["\']([^"\']+)["\']', text, flags=re.S):
        for item in m[1].split(','):
            name = item.strip().split(' as ')[-1]
            if len(re.findall(r'\b' + re.escape(name) + r'\b', text)) == 1:
                no_local_import_use.append({'file': file, 'name': name, 'import_path': m[2]})
save('screen.json', {'method': 'Token-level lead generation, comments stripped and strings retained; not a semantic reachability proof. Manually adjudicated against live source and historical consumers.', 'low_reference_symbols': low, 'imports_without_local_use': no_local_import_use})
symbols = sorted(set(low) | {'FeeDistributorAccounting', 'BountyScripts', 'GaugeBounty', 'CurveGaugeListerV2', 'AlwaysTrueTrustedValidator', 'PoisonAddController', 'get_gauge_weight', 'T_QUARTER_RELEASED', 'T_FEE_CHECKPOINT_RESULT'})
search = {}
for symbol in symbols:
    entry = {}
    for revision in (BASE, CAND):
        argv = ['git', 'grep', '-n', '-w', symbol, revision, '--', *SCOPES]
        r = subprocess.run(argv, cwd=ROOT, capture_output=True, text=True)
        assert r.returncode in (0, 1)
        stem = symbol + '.' + revision[:7]
        (OUT / (stem + '.stdout')).write_text(r.stdout)
        (OUT / (stem + '.stderr')).write_text(r.stderr)
        entry[revision] = {'argv': argv, 'cwd': str(ROOT), 'exit': r.returncode, 'matches': r.stdout.splitlines()}
    search[symbol] = entry
save('searches.json', search)
for symbol in ('_hasLog', 'log_named_bytes32'):
    live = search[symbol][CAND]['matches']
    historical = search[symbol][BASE]['matches']
    assert len(live) == 1 and ':test/fork/ForkFixture.sol:' in live[0]
    assert len(historical) == 3
    assert all(':test/fork/bounty/ForkDuplicateBallot.t.sol:' in x for x in historical if ':test/fork/ForkFixture.sol:' not in x)

# Keep full declaration-to-occurrence index for product interfaces/functions/events/errors.
product_symbols = sorted(set(m[1] for p, s in code.items() if p.startswith('contracts/') and '/mocks/' not in p for m in re.finditer(r'\b(?:function|event|error|interface|library|constant)\s+(\w+)', s)))
uses = {}
for symbol in product_symbols:
    rx = re.compile(r'\b' + re.escape(symbol) + r'\b')
    uses[symbol] = [{'file': p, 'line': n, 'text': line} for p, s in new.items() for n, line in enumerate(s.splitlines(), 1) if rx.search(line)]
save('product-symbol-occurrences.json', uses)
imports = []
for p, s in new.items():
    if not p.endswith('.sol'):
        continue
    for m in re.finditer(r'import\s+(?:.*?\s+from\s+)?["\']([^"\']+)["\']\s*;', s, re.S):
        target = os.path.normpath(str(Path(p).parent / m[1]))
        assert target in new, (p, target)
        imports.append({'source': p, 'target': target})
save('import-closure.json', imports)
manifest = json.loads(git('show', CAND + ':plans/V1ALIGN-MANIFEST.json'))
assert not any(re.search('bounty', s, re.I) for p, s in new.items() if p.startswith('contracts/'))
assert all(p not in new for p in manifest['remove_product_sources'])
for p, h in manifest['unchanged_shared_source_sha256'].items():
    assert hashlib.sha256(new[p].encode()).hexdigest() == h

# Current docs are exact accepted payloads, not fresh deployment verification.
docs = tree(CAND, ['README.md', 'docs'])
authority = git('show', CAND + ':plans/V1ALIGN-DOC-DELTAS.md').decode()
doc_checks = {}
for m in re.finditer(r'BEGIN_FILE (.+)\n(.*?)END_FILE \1', authority, re.S):
    doc_checks[m[1]] = docs[m[1]] == m[2]
old_intro = re.search(r'BEGIN_OLD_INTEL\n(.*?)END_OLD_INTEL', authority, re.S)[1]
new_intro = re.search(r'BEGIN_NEW_INTEL\n(.*?)END_NEW_INTEL', authority, re.S)[1]
historical = git('show', BASE + ':docs/INTEL-YB-HELPERS.md').decode()
doc_checks['docs/INTEL-YB-HELPERS.md'] = historical.replace(old_intro, new_intro) == docs['docs/INTEL-YB-HELPERS.md']
assert all(doc_checks.values())
assert 'docs/BOUNTY-ABI.md' not in docs and 'docs/BOUNTY-OPERATIONS.md' not in docs
save('docs-exact.json', doc_checks)
(OUT / 'amendment-core.diff').write_bytes(git('diff', BASE, CAND, '--', 'contracts/CurveGaugeLister.sol'))
(OUT / 'amendment-product-paths.txt').write_bytes(git('diff', '--name-status', BASE, CAND, '--', 'contracts'))

# Fresh product-only builds: no historical tests or network operations are invoked.
hist = WORK / 'pre-amendment'
env = {k: v for k, v in os.environ.items() if not k.startswith(('FOUNDRY_', 'DAPP_')) and k not in ('MAINNET_RPC_URL', 'XDG_CACHE_HOME', 'XDG_CONFIG_HOME', 'XDG_DATA_HOME', 'SVM_HOME')}
home = WORK / 'gate-home'
env.update(HOME=str(home), XDG_CACHE_HOME=str(home / '.cache'), XDG_CONFIG_HOME=str(home / '.config'), XDG_DATA_HOME=str(home / '.local/share'), NO_COLOR='1')
sizes = {}
for profile, output in (('default', 'out'), ('fork', 'out-fork')):
    argv = ['forge', 'build', '--offline', '--sizes', '--skip', 'test', '--skip', 'script']
    start = datetime.datetime.now(datetime.timezone.utc).isoformat()
    t = time.monotonic()
    with (OUT / ('historical-build-' + profile + '.stdout')).open('w') as out, (OUT / ('historical-build-' + profile + '.stderr')).open('w') as err:
        r = subprocess.run(argv, cwd=hist, env=dict(env, FOUNDRY_PROFILE=profile), stdout=out, stderr=err, timeout=600)
    save('historical-build-' + profile + '.json', {'argv': argv, 'cwd': str(hist), 'revision': BASE, 'profile': profile, 'start': start, 'end': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'elapsed_seconds': time.monotonic() - t, 'exit': r.returncode})
    assert r.returncode == 0
    sizes[profile] = {}
    for name in ('CurveGaugeLister', 'VotiumAdapter', 'VoteMarketAdapter'):
        data = json.loads((hist / output / (name + '.sol') / (name + '.json')).read_text())
        entry = {}
        for key in ('bytecode', 'deployedBytecode'):
            raw = bytes.fromhex(data[key]['object'].removeprefix('0x'))
            entry[key] = {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}
        sizes[profile][name] = entry
    print('historical build', profile, 'exit', r.returncode, flush=True)
save('historical-sizes.json', sizes)
assert not git('-C', str(hist), 'diff', '--name-only')
save('verification.json', {'candidate': CAND, 'historical_baseline': BASE, 'scope': SCOPES, 'imports_resolve': True, 'no_bounty_product_text': True, 'manifest_deletions_absent': True, 'shared_frozen_source_hashes_match': True, 'accepted_document_payloads_unchanged': True, 'cut_lineage_exact': ['_hasLog', 'log_named_bytes32'], 'historical_builds_read_only': True})
print('Sweep evidence and pre-amendment sizes verified', flush=True)
