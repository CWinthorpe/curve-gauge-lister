#!/usr/bin/env python3
"""Read-only gate collector. Writes receipts outside the disposable checkout."""
import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import time

p = argparse.ArgumentParser()
p.add_argument('checkout', type=Path)
p.add_argument('receipts', type=Path)
p.add_argument('--home', type=Path, required=True)
p.add_argument('--cold', action='store_true')
a = p.parse_args()
a.checkout = a.checkout.resolve()
a.receipts.mkdir(parents=True, exist_ok=False)
a.home.mkdir(parents=True, exist_ok=True)
env = {k: v for k, v in os.environ.items() if not k.startswith(('FOUNDRY_', 'DAPP_')) and k not in ('MAINNET_RPC_URL', 'XDG_CACHE_HOME', 'XDG_CONFIG_HOME', 'XDG_DATA_HOME', 'SVM_HOME')}
env.update(HOME=str(a.home), XDG_CACHE_HOME=str(a.home / '.cache'), XDG_CONFIG_HOME=str(a.home / '.config'), XDG_DATA_HOME=str(a.home / '.local/share'), FOUNDRY_PROFILE='default', NO_COLOR='1')
solc = a.home / '.local/share/svm/0.8.30/solc-0.8.30'
solc.parent.mkdir(parents=True, exist_ok=True)
if not solc.exists():
    shutil.copy2('/home/winny/.local/share/svm/0.8.30/solc-0.8.30', solc)
if a.cold:
    assert not (a.home / '.foundry/cache/rpc').exists()
    assert not any((a.checkout / x).exists() for x in ('out', 'out-fork', 'cache', 'cache-fork'))


def save(name, value):
    (a.receipts / name).write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')


def snapshot():
    files = subprocess.check_output(['git', 'ls-files', '-z'], cwd=a.checkout).decode().split('\0')
    return {f: hashlib.sha256((a.checkout / f).read_bytes()).hexdigest() if (a.checkout / f).is_file() else None for f in files if f}


before = snapshot()
save('input-before.json', before)
save('binding.json', {'checkout': str(a.checkout), 'head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=a.checkout).decode().strip(), 'cold': a.cold, 'home': str(a.home), 'rpc_cache_absent_at_start': not (a.home / '.foundry/cache/rpc').exists()})
commands = []


def run(name, argv, profile='default', rpc=None, expected=0, timeout=600):
    e = dict(env, FOUNDRY_PROFILE=profile)
    if rpc is not None:
        e['MAINNET_RPC_URL'] = rpc
    start = datetime.datetime.now(datetime.timezone.utc).isoformat()
    t = time.monotonic()
    with (a.receipts / (name + '.stdout')).open('w') as out, (a.receipts / (name + '.stderr')).open('w') as err:
        result = subprocess.run(argv, cwd=a.checkout, env=e, stdout=out, stderr=err, timeout=timeout)
    meta = {'argv': argv, 'cwd': str(a.checkout), 'profile': profile, 'MAINNET_RPC_URL': rpc, 'HOME': str(a.home), 'start': start, 'end': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'elapsed_seconds': time.monotonic()-t, 'exit': result.returncode, 'expected_exit': expected}
    save(name + '.json', meta)
    commands.append(meta | {'name': name})
    print(name, 'exit', result.returncode, 'seconds', round(meta['elapsed_seconds'], 3), flush=True)
    assert result.returncode == expected, (name, result.returncode, expected)
    return (a.receipts / (name + '.stdout')).read_text()


run('git-diff-check', ['git', 'diff', '--check'])
run('forge-version', ['forge', '--version'])
run('solc-version', [str(solc), '--version'])
run('fmt', ['forge', 'fmt', '--check'])
for profile in ('default', 'fork'):
    cfg = json.loads(run('config-' + profile, ['forge', 'config', '--json'], profile))
    assert cfg['optimizer'] is True and cfg['optimizer_runs'] == 200 and not cfg['via_ir']
    assert cfg['evm_version'] == ('paris' if profile == 'default' else 'cancun')
    assert cfg['test'] == ('test' if profile == 'default' else 'fork')
    assert cfg['out'] == ('out' if profile == 'default' else 'out-fork')
    run('build-' + profile, ['forge', 'build', '--offline', '--sizes', '--extra-output', 'storageLayout'], profile)
    run('list-' + profile, ['forge', 'test', '--offline', '--list', '--json'], profile)
run('offline-unset', ['forge', 'test', '--offline', '-vvv'])
run('offline-unreachable', ['forge', 'test', '--offline', '-vvv'], rpc='http://127.0.0.1:1')
run('fork-online', ['bash', 'scripts/test-fork.sh'], 'fork', 'https://eth-mainnet.public.blastapi.io', timeout=900)
run('fork-warm', ['bash', 'scripts/test-fork.sh'], 'fork', 'https://eth-mainnet.public.blastapi.io', timeout=900)
run('fork-unreachable', ['bash', 'scripts/test-fork.sh'], 'fork', 'http://127.0.0.1:1', expected=1)
unreachable = ''.join((a.receipts / ('fork-unreachable.' + ext)).read_text() for ext in ('stdout', 'stderr'))
assert 'refusing to run fork tests' in unreachable and '[PASS]' not in unreachable and 'Ran ' not in unreachable
inventory = json.loads((a.checkout / 'plans/V1ALIGN-WITNESS-INVENTORY.json').read_text())['identities']
manifest = json.loads((a.checkout / 'plans/V1ALIGN-MANIFEST.json').read_text())
results = {}
sizes = {}
artifacts_dir = a.receipts / 'artifacts'
artifacts_dir.mkdir()
for profile, output in (('default', 'out'), ('fork', 'out-fork')):
    listed = json.loads((a.receipts / ('list-' + profile + '.stdout')).read_text())
    expected = sorted(r['target_identity_or_counterpart'].rsplit(':', 1)[0] + ':' + r['target_signature_or_counterpart'] for r in inventory if r['profile'] == profile and r['disposition'] in ('RETAIN_V1', 'PORT_TRUST'))
    discovered = []
    for file, contracts in listed.items():
        for contract, names in contracts.items():
            artifact = json.loads((a.checkout / output / Path(file).name / (contract + '.json')).read_text())
            for name in names:
                signatures = [s for s in artifact['methodIdentifiers'] if s.split('(')[0] == name]
                assert len(signatures) == 1, (file, contract, name, signatures)
                discovered.append(file + ':' + contract + ':' + signatures[0])
    assert sorted(discovered) == expected
    assert len(expected) == len(set(expected)) == (77 if profile == 'default' else 13)
    per_run = {}
    for run_name in (('offline-unset', 'offline-unreachable') if profile == 'default' else ('fork-online', 'fork-warm')):
        text = (a.receipts / (run_name + '.stdout')).read_text()
        actual = []
        suite = None
        for line in text.splitlines():
            m = re.match(r'Ran \d+ tests? for (.+)', line)
            if m:
                suite = m.group(1)
            m = re.match(r'\[PASS\] (.+) \(gas:', line)
            if m:
                assert suite
                actual.append(suite + ':' + m.group(1))
        assert sorted(actual) == expected, (run_name, sorted(set(expected) - set(actual)), sorted(set(actual) - set(expected)))
        assert '[FAIL' not in text and '[SKIP' not in text
        summary = re.findall(r'(\d+) tests passed, (\d+) failed, (\d+) skipped', text)
        assert summary and tuple(map(int, summary[-1])) == (len(expected), 0, 0), (run_name, summary)
        per_run[run_name] = sorted(actual)
    results[profile] = {'expected': expected, 'discovered': sorted(discovered), 'passes': per_run, 'exact_set_equality': True}
    sizes[profile] = {}
    for file in sorted((a.checkout / output).glob('*/*.json')):
        data = json.loads(file.read_text())
        if 'deployedBytecode' not in data or 'bytecode' not in data:
            continue
        objects = {}
        for key in ('bytecode', 'deployedBytecode'):
            s = data[key]['object'].removeprefix('0x')
            raw = bytes.fromhex(s)
            objects[key] = {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}
        sizes[profile][str(file.relative_to(a.checkout / output))] = objects
    for name in ('CurveGaugeLister', 'VotiumAdapter', 'VoteMarketAdapter'):
        f = name + '.sol/' + name + '.json'
        data = json.loads((a.checkout / output / f).read_text())
        shutil.copy2(a.checkout / output / f, artifacts_dir / (profile + '-' + name + '.json'))
        abi = manifest['abi'] if name == 'CurveGaugeLister' else manifest['unchanged_adapter_abi'][f]
        ids = manifest['methodIdentifiers'] if name == 'CurveGaugeLister' else manifest['unchanged_adapter_methodIdentifiers'][f]
        assert sorted(data['abi'], key=lambda x: json.dumps(x, sort_keys=True)) == sorted(abi, key=lambda x: json.dumps(x, sort_keys=True))
        assert data['methodIdentifiers'] == ids
        assert sizes[profile][f]['deployedBytecode']['bytes'] <= 24576
        assert sizes[profile][f]['bytecode']['bytes'] + {'CurveGaugeLister': 320, 'VotiumAdapter': 96, 'VoteMarketAdapter': 128}[name] <= 49152
for file, sha in manifest['unchanged_shared_source_sha256'].items():
    assert hashlib.sha256((a.checkout / file).read_bytes()).hexdigest() == sha, file
for file in manifest['remove_product_sources']:
    assert not (a.checkout / file).exists(), file
save('identities.json', results)
save('sizes.json', sizes)
after = snapshot()
save('input-after.json', after)
assert before == after
save('verification.json', {'all_native_exits_expected': True, 'input_bytes_unchanged': True, 'exact_default_identities': 77, 'exact_fork_identities': 13, 'no_failures_or_skips': True, 'abi_and_method_identifiers_match_manifest_both_profiles': True, 'manifest_shared_sources_unchanged': True, 'deleted_sources_absent': True, 'warm_unreachable_fork_rejected_before_tests': True, 'commands': commands})
print('VERIFIED: exact 77/13 identities, both profiles, input byte equality', flush=True)
