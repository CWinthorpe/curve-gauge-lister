#!/usr/bin/env python3
"""Dispose only ignored Foundry outputs after recording stale-artifact diagnosis."""
from pathlib import Path
import datetime
import json
import os
import subprocess

work = Path(__file__).resolve().parent
root = Path('/home/winny/curve-gauge-lister')
out = work / 'receipts/L01-artifact-cleanup'
out.mkdir(exist_ok=False)
trial = json.loads((work / 'receipts/L01-trial/sizes.json').read_text())
landed = json.loads((work / 'receipts/L01-landed/sizes.json').read_text())
diagnosis = {}
for profile in trial:
    extra = sorted(set(landed[profile]) - set(trial[profile]))
    missing = sorted(set(trial[profile]) - set(landed[profile]))
    differences = sorted(k for k in set(trial[profile]) & set(landed[profile]) if trial[profile][k] != landed[profile][k])
    assert extra and not missing and not differences
    diagnosis[profile] = {'stale_untracked_artifacts': extra, 'missing_artifacts': missing, 'common_artifact_differences': differences}
(out / 'diagnosis.json').write_text(json.dumps({'failed_comparison': 'entire L01-landed/sizes.json equals L01-trial/sizes.json', 'comparison_exit': 1, 'native_gates_passed': True, 'disposition': 'Keep initial receipts. Clean only untracked local Foundry outputs, then repeat all landed gates. No source/test change.', 'profiles': diagnosis}, indent=2) + '\n')
assert not subprocess.check_output(['git', 'ls-files', 'out', 'out-fork', 'cache', 'cache-fork'], cwd=root)
env = {k: v for k, v in os.environ.items() if not k.startswith(('FOUNDRY_', 'DAPP_')) and k not in ('MAINNET_RPC_URL', 'XDG_CACHE_HOME', 'XDG_CONFIG_HOME', 'XDG_DATA_HOME', 'SVM_HOME')}
for profile in ('default', 'fork'):
    command = ['forge', 'clean']
    e = dict(env, FOUNDRY_PROFILE=profile)
    start = datetime.datetime.now(datetime.timezone.utc).isoformat()
    r = subprocess.run(command, cwd=root, env=e, capture_output=True, text=True)
    (out / (profile + '.stdout')).write_text(r.stdout)
    (out / (profile + '.stderr')).write_text(r.stderr)
    (out / (profile + '.json')).write_text(json.dumps({'argv': command, 'cwd': str(root), 'profile': profile, 'start': start, 'end': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'exit': r.returncode}, indent=2) + '\n')
    assert r.returncode == 0
assert all(not (root / p).exists() for p in ('out', 'out-fork', 'cache', 'cache-fork'))
print('Ignored stale outputs removed; source unchanged; repeat full landed gates.')
