#!/usr/bin/env python3
"""Compare each surgical trial to its cumulative predecessor and bind reapplication."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess

p = argparse.ArgumentParser()
p.add_argument('mode', choices=['trial', 'restored', 'applied'])
p.add_argument('item')
p.add_argument('checkout', type=Path)
p.add_argument('before', type=Path)
p.add_argument('after', type=Path)
a = p.parse_args()
work = Path(__file__).resolve().parent
out = work / 'receipts' / (a.item + '-custody')
out.mkdir(exist_ok=True)
file = 'test/fork/ForkFixture.sol'


def load(root, name):
    return json.loads((root / name).read_text())


def snapshot():
    names = subprocess.check_output(['git', 'ls-files', '-z'], cwd=a.checkout).decode().split('\0')
    return {p: hashlib.sha256((a.checkout / p).read_bytes()).hexdigest() if (a.checkout / p).is_file() else None for p in names if p}


def save(name, data):
    target = out / name
    assert not target.exists(), target
    target.write_text(json.dumps(data, indent=2, sort_keys=True) + '\n')


before = load(a.before, 'input-after.json')
after = load(a.after, 'input-after.json')
current = snapshot()
if a.mode == 'trial':
    assert load(a.after, 'verification.json')['input_bytes_unchanged']
    changed = sorted(p for p in set(before) | set(after) if before.get(p) != after.get(p))
    assert changed == [file], changed
    assert current == after
    diff = subprocess.check_output(['git', 'diff', '--', file], cwd=a.checkout)
    assert diff and not any(line.startswith(b'+') and not line.startswith(b'+++') for line in diff.splitlines())
    patch = out / 'cut.patch'
    assert not patch.exists()
    patch.write_bytes(diff)
    # Compare all compiled sizes as well as full metadata-inclusive product bytes.
    old_sizes, new_sizes = load(a.before, 'sizes.json'), load(a.after, 'sizes.json')
    deltas = {}
    for profile in old_sizes:
        assert set(old_sizes[profile]) == set(new_sizes[profile])
        deltas[profile] = {artifact: {kind: new_sizes[profile][artifact][kind]['bytes'] - values[kind]['bytes'] for kind in values} for artifact, values in old_sizes[profile].items()}
        for name in ('CurveGaugeLister', 'VotiumAdapter', 'VoteMarketAdapter'):
            key = name + '.sol/' + name + '.json'
            assert old_sizes[profile][key] == new_sizes[profile][key]
        for name in ('VotiumAdapter', 'VoteMarketAdapter'):
            key = name + '.sol/' + name + '.json'
            manifest = json.loads((a.checkout / 'plans/V1ALIGN-MANIFEST.json').read_text())
            expected = manifest['unchanged_adapter_runtime_by_profile'][profile][key]
            assert new_sizes[profile][key]['deployedBytecode']['sha256'] == expected['runtime_sha256_decoded']
    assert load(a.before, 'identities.json') == load(a.after, 'identities.json')
    old_text = subprocess.check_output(['git', 'show', 'HEAD:' + file], cwd=a.checkout)
    new_text = (a.checkout / file).read_bytes()
    save('trial.json', {'changed_paths': changed, 'frozen_all_other_tracked_paths_byte_equal': True, 'all_product_creation_and_runtime_bytes_equal': True, 'adapter_certified_runtime_hashes_equal': True, 'census_exact_equality': True, 'source_before_bytes': len(old_text), 'source_after_bytes': len(new_text), 'source_delta_bytes': len(new_text) - len(old_text), 'source_removed_lines': len(old_text.splitlines()) - len(new_text.splitlines()), 'patch_sha256': hashlib.sha256(diff).hexdigest(), 'artifact_size_deltas': deltas, 'before_sizes': old_sizes, 'after_sizes': new_sizes})
    print(a.item, 'trial verified; source bytes delta', len(new_text) - len(old_text), 'all product sizes unchanged')
elif a.mode == 'restored':
    # A later brief may add a tracked file; exact common predecessor inputs must match.
    assert all(current.get(p) == h for p, h in before.items())
    assert not subprocess.check_output(['git', 'diff', '--name-only'], cwd=a.checkout)
    save('restored.json', {'checkout': str(a.checkout), 'head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=a.checkout).decode().strip(), 'predecessor_input_hashes': before, 'actual_input_hashes': current, 'all_predecessor_inputs_exact': True, 'git_diff_empty': True})
    print(a.item, 'restored exactly')
else:
    assert all(current.get(p) == h for p, h in after.items())
    diff = subprocess.check_output(['git', 'diff', '--', file], cwd=a.checkout)
    assert diff == (out / 'cut.patch').read_bytes()
    # Only the pre-existing lean brief can be additional to the initial candidate.
    extras = sorted(set(current) - set(after))
    assert extras in ([], ['plans/V1ALIGN-LEAN-BRIEF.md']), extras
    save('applied.json', {'checkout': str(a.checkout), 'actual_input_hashes': current, 'trial_inputs_exact': True, 'trial_patch_exact': True, 'additional_tracked_paths': extras})
    print(a.item, 'reapplication matches gated trial exactly')
